As stated in my discussion, I have not submitted a CMakeLists.txt file
Discussion Title: Assignment 2 Submission Question

I have tested that my code works as expected with my local QTCreator/OpenCV setup.

Please reference the demo video attached or contact me if you have any issues running my code.